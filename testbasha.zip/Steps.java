package stepDefinitions;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Verify;

import UIelements.UIElements;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Githubobjects;

public class Steps {	
	WebDriver driver;
	
	//**********************************************/*a. Navigate to GitHub.com*****************************************************************************/
	@Given("I have link  {string}")
	public void i_have_link(String string) {
		System.setProperty("webdriver.chrome.driver","G:\\SELENIUM  PRACTISE\\Chrome\\chromedriver.exe\\");//https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLoginhttps://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin
		driver = new ChromeDriver();
		driver.manage().window().maximize();		
		driver.get("https://github.com/");				
	}

	//*******************************************************/* b.	Enter a search term.********************************************************************/		
	//This search term should be configurable via the Gherkin statement.ii.	For this test, use ‘hygieia’ for the search term
		@When("I enter valid {string}")
	public void i_enter_valid(String hygieia) throws Exception {
		Githubobjects pobj = new Githubobjects(driver);
		UIElements elements= new UIElements(driver);
		elements.setText(pobj.Search_field, "hygieia");
	}

	@When("click search")
	public void click_search() throws Exception {
		Githubobjects pobj = new Githubobjects(driver);
		UIElements elements= new UIElements(driver);
		elements.mousehover(pobj.All_github_btn);
		elements.waittime(1000);
		elements.clickbutton(pobj.All_github_btn);			
	}
	
	
	@Then("is should display the Result")
	public void is_should_display_the_Result()  throws Exception{		
		Githubobjects pobj = new Githubobjects(driver);
		UIElements elements= new UIElements(driver);
		try {
			//String repo_header= elements.getLoginTitle(pobj.repo_header);
		    String repo_header=driver.findElement(By.xpath("//*[@id=\"js-pjax-container\"]/div/div[3]/div/div[1]/h3")).getText();
		    System.out.println(repo_header);
			String[] repos_count = repo_header.split(" ");
			System.out.println(repos_count[0]);	
			elements.waittime(1000);				
            driver.findElement(By.xpath("//*[@name='q']")).clear();
			
		    //elements.cleartext(pobj.All_github_btn);
			elements.waittime(1000);
			elements.setText(pobj.Search_field, "capitalone/Hygieia");
			elements.waittime(1000);
			elements.mousehover(pobj.All_github_btn1);
			elements.waittime(1000);
			//elements.clickbutton(pobj.All_github_btn1);
			driver.findElement(By.xpath("//*[@id=\"jump-to-suggestion-search-global\"]/a/div[3]/span[2]")).click();			
				
			if(Integer.parseInt(repos_count[0])>=3)
			{		
			//elements.clickbutton(pobj.hygiea_link);
			driver.findElement(By.xpath("//*[@id=\"js-pjax-container\"]/div/div[3]/div/ul/li[2]/div[1]/h3/a")).click();				
			//String headers_list=elements.getLoginTitle(pobj.headers_1);
			String headers_list =driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]")).getText();
			System.out.println("Headerslist is :"+"\n"+ headers_list);
			Verify.verify(headers_list.contains("commit"));
			Verify.verify(headers_list.contains("branch"));
			Verify.verify(headers_list.contains("releases"));
			Verify.verify(headers_list.contains("contributors"));			
				
			/*String commits_no = elements.getLoginTitle(pobj.commits_count);
			String branch_no  = elements.getLoginTitle(pobj.branch_count);
			String releases_no  = elements.getLoginTitle(pobj.releases_count);
			String contributors_no = elements.getLoginTitle(pobj.contributors_count);*/
			String commits_no = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[1]/a/span")).getText();
			String branch_no  = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[2]/a/span")).getText();
			String releases_no  = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[3]/a/span")).getText();
			String contributors_no = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[4]/a/span")).getText();
			
			System.out.println("commits_count is :"+commits_no);
			System.out.println("branch_count is :"+branch_no);
			System.out.println("releases_count is :"+releases_no);
			System.out.println("contributors_count is :"+contributors_no);		
			

			int i=Integer.parseInt(commits_no);
			if( i>2000)
			{
				System.out.println("PASSED");
			}
			else {
				System.out.println("FAILED");
			}
			
			int j=Integer.parseInt(branch_no);
			if( j>4)
			{
				System.out.println("PASSED");
			}
			else {
				System.out.println("FAILED");
			}		
			int k=Integer.parseInt(releases_no);
			if( k>=8)
			{
				System.out.println("PASSED");
			}
			else {
				System.out.println("FAILED");
			}
			
			int l=Integer.parseInt(contributors_no);
			if( l>50)
			{
				System.out.println("PASSED");
			}
			else {
				System.out.println("FAILED");
			}		
			}
		    } catch(NoSuchElementException e){
			}

	}



}
