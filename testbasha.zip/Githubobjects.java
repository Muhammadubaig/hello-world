package pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Githubobjects {
	WebDriver driver;
	public Githubobjects(WebDriver driver) {
	     PageFactory.initElements(driver, this);
	 }
	
	 @FindBy(xpath="//*[@name='q']") 
	 public  WebElement Search_field;
	 
	 @FindBy(xpath="//*[@id=\"jump-to-suggestion-search-global\"]/a/div[3]/span[2]")
	 public WebElement All_github_btn;
	 
	 @FindBy(xpath="//*[@id=\"jump-to-suggestion-search-global\"]/a/div[3]/span[2]")
	 public WebElement All_github_btn1;
	 
	 @FindBy(xpath="//*[@id=\\\"js-pjax-container\\\"]/div/div[3]/div/div[1]/h3")
	 public WebElement repo_header;
		
	 @FindBy(xpath="//*[@id=\\\"js-pjax-container\\\"]/div/div[3]/div/div[1]/h3")
	 public String repos_count;
	 
	 @FindBy(xpath="//*[@id=\\\"js-pjax-container\\\"]/div/div[3]/div/ul/li[2]/div[1]/h3/a")
	 public WebElement hygiea_link;
	 
	 @FindBy(xpath="//*[@id=\\\"js-repo-pjax-container\\\"]/div[2]/div/div[3]") 
	 public WebElement headers_1;
	  
	 
	 @FindBy(xpath="//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[1]/a/span") 
	 public WebElement commits_count;
	 
	 @FindBy(xpath="//*[@id=\\\"js-repo-pjax-container\\\"]/div[2]/div/div[3]") 
	 public WebElement branch_count;
	 
	 @FindBy(xpath="//*[@id=\\\"js-repo-pjax-container\\\"]/div[2]/div/div[3]") 
	 public WebElement releases_count;
	 
	 @FindBy(xpath="//*[@id=\\\"js-repo-pjax-container\\\"]/div[2]/div/div[3]") 
	 public WebElement contributors_count;

	
	 	 
	 
	 public void setText(WebElement element,String value) 
	 {
	  element.sendKeys(value);			
	 }
				
	 public void cleartext(WebElement element)
	 {
	  element.clear();
	 }
		
	 public void click(WebElement element)
	 {
	  element.click();		
	 } 
		
	 public void Selectdropdown1(WebElement element,String Selectbyvisisbletext) 
	 {
	  Select dropdown =new Select(element);
      dropdown.selectByVisibleText(Selectbyvisisbletext);		
	 }
		
	 public void Selectdropdown2(WebElement element,int selectByIndex)
	 {
	  Select dropdown =new Select(element);
	  dropdown.selectByIndex(selectByIndex);		
	 }
		
	 public void Selectdropdown3(WebElement element,String selectByvalue)
	 {
	  Select dropdown =new Select(element);
      dropdown.selectByValue(selectByvalue);		
	 }
		
	 public void Selectcheckbox(WebElement element) 
	 {
		element.sendKeys(Keys.SPACE);
	 }
		
	 public void waittime(long millisec) throws Exception 
	 {
	  Thread.sleep(millisec);
	 }	
		
	 public void mousehover(WebElement element) {
	 try {	
			Actions action = new Actions(driver);				
			action.moveToElement(element).build().perform();
			Thread.sleep(1000);
			JavascriptExecutor JS = (JavascriptExecutor)driver;
			JS.executeScript("arguments[0]"," click()","clickable");
			}catch(Exception e)
			{}			
		}
		
		public void mulitimousehover(WebElement element1,WebElement element2) {
			try {			
			Actions action = new Actions(driver);				
			action.moveToElement(element1).build().perform();
			action.moveToElement(element2).build().perform();
			Thread.sleep(1000);
			JavascriptExecutor JS = (JavascriptExecutor)driver;
			JS.executeScript("arguments[0]"," click()","clickable");
			}catch(Exception e)
			{}
		}
		
		public void contextclick(WebElement element) {
			try {
			//Amazon_loginpage login = new Amazon_loginpage();
			Actions action = new Actions(driver);				
			action.contextClick(element).build().perform();
			Thread.sleep(1000);
			JavascriptExecutor JS = (JavascriptExecutor)driver;
			JS.executeScript("arguments[0]"," click()","clickable");
			}catch(Exception e)
			{}			
		}

		
		 public void UIidentifiers(WebElement element,String strUserName){

			    //Fill user name	        
				this.setText(element, strUserName);

		        //clear data
				this.cleartext(element);

		        //Click Login button
		        this.click(element);
		        
		        // Mousehover action
		        this.mousehover(element);

		  }
	 
	 
}
