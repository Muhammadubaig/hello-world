package SeleniumTests;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.google.common.base.Verify;

import junit.framework.Assert;

public class Homepage {

public static void main(String[] args) throws Exception {
	WebDriver driver;
	
	System.setProperty("webdriver.chrome.driver","G:\\SELENIUM  PRACTISE\\Chrome\\chromedriver.exe\\");//https://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLoginhttps://accounts.google.com/signin/v2/identifier?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	
	//**********************************************/*a.	Navigate to GitHub.com*****************************************************************************/
	
	driver.get("https://github.com/");
	
	//*******************************************************/* b.	Enter a search term.********************************************************************/
	
	// i.	This search term should be configurable via the Gherkin statement.ii.	For this test, use ‘hygieia’ for the search term*/
			
	driver.findElement(By.xpath("//*[@name='q']")).sendKeys("hygieia");		
	Actions action = new Actions(driver);
	Thread.sleep(1000);
	WebElement githubbutn = driver.findElement(By.xpath("//*[@id=\"jump-to-suggestion-search-global\"]/a/div[3]/span[2]"));
	action.moveToElement(githubbutn).build().perform();
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"jump-to-suggestion-search-global\"]/a/div[3]/span[2]")).click();
	
	
	//******************************************/*c.	After the search action completes. Verify that the correct number of repos is returned.************************************************************************/
	//i.	The number of repos should be configurable via the Gherkin.
		
	try {
		
	    String repo_header=driver.findElement(By.xpath("//*[@id=\"js-pjax-container\"]/div/div[3]/div/div[1]/h3")).getText();
	    System.out.println(repo_header);
		String[] repos_count = repo_header.split(" ");
		System.out.println(repos_count[0]);		
		
		
	//***********************************************/* d.	Next, select the "capitalone/Hygieia” repository************************************************************/
		//c.ii.	For this test, set a value >= 3
		
		driver.findElement(By.xpath("//*[@name='q']")).clear();
		Thread.sleep(500);
		driver.findElement(By.xpath("//*[@name='q']")).sendKeys("capitalone/Hygieia");
		Actions action1 = new Actions(driver);
		Thread.sleep(1000);
		WebElement githubbutn1 = driver.findElement(By.xpath("//*[@id=\"jump-to-suggestion-search-global\"]/a/div[3]/span[2]"));
		action.moveToElement(githubbutn1).build().perform();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"jump-to-suggestion-search-global\"]/a/div[3]/span[2]")).click();	
		if(Integer.parseInt(repos_count[0])>=3)
		{		
		driver.findElement(By.xpath("//*[@id=\"js-pjax-container\"]/div/div[3]/div/ul/li[2]/div[1]/h3/a")).click();
				
		//***********************************************/*d.i.	Verify that the following 4 repo headers appear (“Commit”, “Branches”, “releases”, “contributors”)*******************************/ 
		String headerslist =driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]")).getText();
		System.out.println("Headerslist is :"+"\n"+headerslist);
		Verify.verify(headerslist.contains("commit"));
		Verify.verify(headerslist.contains("branch"));
		Verify.verify(headerslist.contains("releases"));
		Verify.verify(headerslist.contains("contributors"));
		
		//***********************************************/*d.ii.	Also verify that the 4 headers have at least the following numbers of counts:*******************************/
		/* 
		1.	commits > 2,000
		2.	branches > 4
		3.	releases >= 8
		4.	contributors > 50*/		
		String commits_count = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[1]/a/span")).getText();
		String branch_count  = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[2]/a/span")).getText();
		String releases_count  = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[3]/a/span")).getText();
		String contributors_count = driver.findElement(By.xpath("//*[@id=\"js-repo-pjax-container\"]/div[2]/div/div[3]/ul/li[4]/a/span")).getText();
		System.out.println("commits_count is :"+commits_count);
		System.out.println("branch_count is :"+branch_count);
		System.out.println("releases_count is :"+releases_count);
		System.out.println("contributors_count is :"+contributors_count);		
		

		int i=Integer.parseInt(commits_count);
		if( i>2000)
		{
			System.out.println("PASSED");
		}
		else {
			System.out.println("FAILED");
		}
		
		int j=Integer.parseInt(branch_count);
		if( j>4)
		{
			System.out.println("PASSED");
		}
		else {
			System.out.println("FAILED");
		}		
		int k=Integer.parseInt(releases_count);
		if( k>=8)
		{
			System.out.println("PASSED");
		}
		else {
			System.out.println("FAILED");
		}
		
		int l=Integer.parseInt(contributors_count);
		if( l>50)
		{
			System.out.println("PASSED");
		}
		else {
			System.out.println("FAILED");
		}		
		}
	    } catch(NoSuchElementException e){
		}
}
}
		
